
<h1>Entri Data Buku</h1>
        <form method="POST" action="pages/prosesGaleri.php" enctype="multipart/form-data">

            <div class="mb-2">
                <label class="form-label">Judul</label>
                <input type="text" class="form-control" name="judul">
            </div>

            <div class="mb-2">
                <label class="form-label">Keterangan</label>
                <input type="file" class="form-control" name="keterangan">
            </div>

            
            
            
            <input type="submit" name="submit" class="btn btn-primary" value="Simpan">
        </form>
        