<div class="mt-3 mb-5">
<h2>
    Welcome to Yamaha MT Club Indonesia
</h2>
<img class="mt-3" src="img/yamahamt.jpg" alt="" style="width: 50rem;"><br>
</div>