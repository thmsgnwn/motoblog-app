<h2>
  About Us
</h2>
<p>

PT Yamaha Indonesia Motor Manufacturing yang dikenal dengan PT YIMM, merupakan perusahaan perakitan kendaraan bermotor roda dua yang berdiri sejak tahun 1974. PT YIMM memiliki visi untuk menjadi perusahaan unggul yang terus bertumbuh berkelanjutan melalui inovasi berdasarkan pengalaman yang menyenangkan untuk menciptakan kesejahteraan dan memperkaya kehidupan masyarakat

</p>

<p>
  YAMAHA MT CLUB INDONESIA merupakan Forum komunikasi para pecinta Yamaha MT di Indonesia.
Forum diskusi dan berbagi info serta pengalaman mengenai motor Yamaha MT dan klub Yamaha MT  serta perusahaan bergerak dibidang pemasaran dan pemasok sparepart terkhusus YAMAHA MT di INDONESIA
</p>

<!-- 
<p>
Forum komunikasi para pecinta Yamaha MT-15 di Indonesia.
Forum diskusi dan berbagi info serta pengalaman mengenai motor Yamaha MT-15 dan klub MOT15 INDONESIA
Group Regulation:
<ul>
  <li>Dilarang memposting segala bentuk yang mengandung SARA</li>
  <li>Dilarang memposting segala sesuatu yang mengandung unsur PORNOGRAFI</li>
  <li>Dilarang memposting atau berkomentar kasar dan mengajak pertikaian</li>
  <li>Dilarang memposting barang jualan berulang kali</li>
  <li>Dilarang melakukan segala bentuk PENIPUAN</li>
  <li>Dilarang memposting komunitas/klub motor dan perekrutan anggota selain dari klub MOT15 INDONESIA</li>
</ul>
Jika melanggar dari peraturan akan dikenakan SANKSI REMOVE AKUN
Berhati-hati, jujur dan cerdaslah dalam melakukan JUAL-BELI
</p> -->