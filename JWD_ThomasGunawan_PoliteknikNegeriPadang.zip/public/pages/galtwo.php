<h2>
MT 25 Series
</h2>

<div class="container text-center">
  <div class="row">
    <div class="col">
      <div class="card"  style="width: 15rem;">  
        <img src="public/img/mt25_black.jpg" alt="MT 15 Series"  title="Warna Black">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/mt25_blue.jpg" alt="MT 15 Series" title="Warna Cyon">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/mt25.jpg" alt="MT 15 Series" title="Warna Biru">
      </div>
    </div>
  </div>
</div>
<br>
<div class="container text-center">
  <div class="row">
    <div class="col">
      <div class="card"  style="width: 15rem;">
        <img src="public/img/jok_mt15.jpg" alt="" title="Jok">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/mesin_mt15.jpg" alt="" title="Mesin">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/knalpot_mt15.jpg" alt="" title="Knalpot">
      </div>
    </div>
  </div>
</div>
<br>
<br>
