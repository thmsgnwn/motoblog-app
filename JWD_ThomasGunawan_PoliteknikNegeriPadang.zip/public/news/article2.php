<article id="pro" class="pro">
  <h2>Warna Baru MT-15, Harga Jadi Rp37 jutaan</h2>
  <p>Yamaha Indonesia rilis dua warna baru buat MT-15. Berkat sentuhan anyar, naked bike 150 cc ini tampil lebih modern. Grafis yang menempel di bodi juga makin memperkuat gaya agresifnya. Per Juli 2022, banderolnya menjadi Rp37,930 juta on the road Jakarta..
  </p>
  <p>Warna baru yang dirilis sebetulnya penyempurnaan dari model sebelumnya. Masih dengan Metallic Dark Grey dan Metallic Blue. Untuk Metallic Dark Grey mewakili perkembangan tren terkini dengan gaya modern sesuai selera market. Dengan dominasi warna abu-abu serta sentuhan kelir cyan yang diaplikasikan pada bagian cover samping dan buritan serta pelek. Menjadikan penampilannya selaras dengan style saat ini namun tetap mengangkat karakter sporty.
  </p>
  <p>
  Sebagai aksen kontras, corak pada sisi buntut hadir dengan desain baru. Sisanya diwarnai hitam. Dari mulai blok mesin, rangka, panel samping, jok, serta knalpot. Upside down bertabung besar itu pula dibungkus cover emas dengan tumpuan hitam.

Skema kedua yakni Metallic Blue masih merepresentasikan biru khas Yamaha. Agak tua, namun tak terlalu muda. Cat itu diaplikasikan di sebagian besar permukaan tangki. Polos. Tanpa grafis sama sekali. Baru di sayap kecil depan tangki ada striping baru dengan desain minimalis. Pelek pun pakai skema yang sama, biru. Identitas baru ini membuat tampilan motor makin gagah dan maskulin serta turut mendongkrak rasa percaya diri penggunanya kala berkendara di jalanan.
  </p>
</article>


