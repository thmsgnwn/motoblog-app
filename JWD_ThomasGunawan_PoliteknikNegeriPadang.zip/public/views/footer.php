
    <!-- footer -->
    <footer>
      <div class="container ">
        <div class="row text-center pt-2">
          <div class="col">
            <p>
              @2023 Moto Blog
              <i
                class="bi bi-heart-fill"
                width="20"
                height="20"
                style="color: plum"
              ></i>
              by: Thomas Gunawan
            </p>
          </div>
        </div>
      </div>
    </footer>
    <!-- akhir footer -->
    

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
      crossorigin="anonymous"
    ></script>

    <script src="js/script.js"></script>
  </body>
</html>

