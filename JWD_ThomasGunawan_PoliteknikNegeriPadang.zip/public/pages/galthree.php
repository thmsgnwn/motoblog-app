<h2>
MT 09 Series
</h2>

<div class="container text-center">
  <div class="row">
    <div class="col">
      <div class="card"  style="width: 15rem;">  
        <img src="public/img/blue_mt09.jpg" alt=""  title="Warna Biru">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/orange_mt09.jpg" alt="" title="Warna Oren">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/matt_mt09.jpg" alt="" title="Warna Abu-abu">
      </div>
    </div>
  </div>
</div>
<br>
<div class="container text-center">
  <div class="row">
    <div class="col">
      <div class="card"  style="width: 15rem;">
        <img src="public/img/tangki_mt09.jpg" alt="" title="Tangki">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/suspensi_mt09.jpg" alt="" title="Suspensi">
      </div>
    </div>
    <div class="col">
    <div class="card"  style="width: 15rem;">
        <img src="public/img/knalpot_mt09.jpg" alt="" title="Knalpot">
      </div>
    </div>
  </div>
</div><br><br>