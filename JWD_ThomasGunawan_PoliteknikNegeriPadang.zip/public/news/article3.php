<article id="pro" class="pro">
  <h2>MT-15 Skemanya Mirip MT-25</h2>
  <p>
  Yamaha Indonesia rilis dua warna anyar buat MT-15. Sentuhan baru di segmen naked sport ini merupakan jawaban dari permintaan konsumen. Tampil lebih fresh dengan kelir Metallic Dark Grey dan Metallic Blue. Masing-masing dipasarkan seharga Rp 37,1 juta on the road Jakarta.

Skema warna yang ada pada tubuh MT-15 sekarang serupa dengan MT-25. Grafis yang menempel di bodi juga makin memperkuat gaya agresifnya. Untuk Metallic Dark Grey menggantikan kelir putih yang sebelumnya eksis. Padanan ini menggabungkan abu-abu gelap, serta striping oranye dan biru muda bertumpuk pada tangki.
  </p>
  <p>
  Sebagai aksen kontras, corak pada sisi buntut hadir dengan desain baru. Sisanya diwarnai hitam. Dari mulai blok mesin, rangka, panel samping, jok, serta knalpot. Upside down bertabung besar itu pula dibungkus cover emas dengan tumpuan silver. Nah, yang tetap jadi ciri khas, pelek palang styish masih dilabur oranye menyala. Warna kontras ini cukup merepresentasikan gaya sporty.
  </p>
  <p>
  Tema kedua adalah Metallic Blue. Posisinya menggantikan yang serba hitam di versi lalu. Bagi orang yang suka komposisi satu warna mungkin agak kecewa. Tapi bisa jadi riset pasar mereka lebih banyak menginginkan sesuatu yang cerah. Ia merupakan biru khas Yamaha. Agak tua namun mentereng. Cat itu diaplikasikan di sebagian besar permukaan tangki. Polos. Tanpa grafis sama sekali. Baru di sayap kecil depan tangki ada striping baru dengan desain minimalis. Dasarnya pun abu, untuk memberikan kontras. Pelek pun pakai skema yang sama, biru. Identitas kuat pabrikan Yamaha ini dapat menjadi kebanggaan tersendiri bagi pemakainya ketika menggebernya di jalanan.
  </p>
</article>


