<h2>
  Galeri Foto
</h2>

<div class="container text-center">
  <div class="row">
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt15" title="Menuju halaman MT 15 Series">
        <img src="public/img/galerymt.jpg" alt="MT 15 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt25"  title="Menuju halaman MT 25 Series">
        <img src="public/img/mt25.jpg" alt="MT 25 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

    <div class=""  >
        <a href="index.php?page=mt09"  title="Menuju halaman MT 09 Series">
        <img src="public/img/mt09.jpg" alt="MT 09 Series" style="width: 15rem;">
        </a>
      </div>

  </div>
</div>

<br>

<div class="row">
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt15" title="Menuju halaman MT 15 Series">
        <img src="public/img/blue_mt09.jpg" alt="MT 15 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt25"  title="Menuju halaman MT 25 Series">
        <img src="public/img/matt_mt09.jpg" alt="MT 25 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

    <div class=""  >
        <a href="index.php?page=mt09"  title="Menuju halaman MT 09 Series">
        <img src="public/img/mt25_black.jpg" alt="MT 09 Series" style="width: 15rem;">
        </a>
      </div>

  </div>
</div>

<br>

<div class="row">
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt15" title="Menuju halaman MT 15 Series">
        <img src="public/img/mt25_blue.jpg" alt="MT 15 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt25"  title="Menuju halaman MT 25 Series">
        <img src="public/img/mt09.jpg" alt="MT 25 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

    <div class=""  >
        <a href="index.php?page=mt09"  title="Menuju halaman MT 09 Series">
        <img src="public/img/cyon.jpg" alt="MT 09 Series" style="width: 15rem;">
        </a>
      </div>

  </div>
</div>

<br>

<div class="row">
    <div class="col">

    <div class=""  >
        <a href="index.php?page=mt25"  title="Menuju halaman MT 25 Series">
        <img src="public/img/mt09.jpg" alt="MT 25 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

      <div class=""  >
        <a href="index.php?page=mt15" title="Menuju halaman MT 15 Series">
        <img src="public/img/mt25_blue.jpg" alt="MT 15 Series" style="width: 15rem;">
        </a>
      </div>

    </div>
    <div class="col">

    <div class=""  >
        <a href="index.php?page=mt09"  title="Menuju halaman MT 09 Series">
        <img src="public/img/cyon.jpg" alt="MT 09 Series" style="width: 15rem;">
        </a>
      </div>

  </div>
</div>

</div>


