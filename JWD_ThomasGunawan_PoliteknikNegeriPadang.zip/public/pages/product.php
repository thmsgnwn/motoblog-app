

<h2>
    Produk Kami
</h2>

<div class="container text-center">
  <div class="row">
    <div class="col"> 

      <div class="card" style="width: 15rem;">
        <img src="public/img/jok_mt15.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text"> 
          Kode: MT23009 <br> 
          Nama : Jok MT <br>
          Harga : Rp.500.000
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/knalpot_mt15.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text"> 
          Kode: MT23007 <br> 
          Nama : Knalpot MT <br>
          Harga : Rp.2500.000
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/suspensi_mt09.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text"> 
          Kode: MT23005 <br> 
          Nama : Suspensi MT <br>
          Harga : Rp.300.000
        </p>
        </div>
     </div>

    </div>
  </div>

  <br>

  <div class="row">
    <div class="col"> 

      <div class="card" style="width: 15rem;">
        <img src="public/img/mesin_mt15.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text"> 
          Kode: MT23009 <br> 
          Nama : Kabel MT <br>
          Harga : Rp.500.000
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/knalpot_mt09.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text"> 
          Kode: MT23099 <br> 
          Nama : Knalpot MT-09 <br>
          Harga : Rp.3000.000
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/tangki_mt09.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text"> 
          Kode: MT23005 <br> 
          Nama : Tangki MT <br>
          Harga : Rp.300.000
        </p>
        </div>
     </div>

    </div>
  </div>


</div>
<br><br>

        