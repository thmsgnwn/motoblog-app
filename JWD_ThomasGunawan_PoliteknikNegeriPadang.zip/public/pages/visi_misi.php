<h2>Visi </h2>
<p>
Menjadi perusahaan distributor motor, beserta jasa dan produk pendukungnya yang TERBESAR di indonesia.
Menjadi perusahaan yang TERPERCAYA dengan didukung oleh :
<ul>
    <li>SDM yang handal</li>
    <li>Sistem pengelolaan keuangan yang solid</li>
    <li>infrastruktur yang tepat guna</li>
</ul>

</p>
<br><br>
<h2>Misi</h2>
<ul>
    <li>
    Melakukan terobosan dan analisa untuk pengembangan bisnis dengan membentuk jaringan-jaringan (penjualan, perawatan dan suku cadang ) baru di seluruh indonesia
    </li>
    <li>
    Memastikan terjadinya pertumbuhan penjualan dan pangsa pasar di setiap wilayah operasional
    </li>
    <li>
    Melakukan strategi bisnis perusahaan yang di dukung oleh strategi kebijakan yang optimal
    </li>
    <li>
    Mengembangkan dan menempatkan karyawan sesuai dengan tuntutan kompetensi jabatan sehingga karyawan memiliki kapasitas serta dapat menjalankan tugas-tugas dan tanggung jawabnya dengan baik
    </li>
    <li>
    Menerapkan Standar Prosedur Operasional yang tepat guna, sebagai landasan kerja untuk menghasilkan kinerja yang optimal
    </li> 
    <li>
    Mengembangkan sisten infrastruktur, informasi teknologi serta sumber daya fisik yang tepat guna dan ter-Intergrasi dengan departement terrkait, sesuai standar yang berlaku .
    </li> 
    <li>
    Melakukan audit internal kontrol secara periodik dan objektif
    </li>
    
</ul>