<h2>
    EVENT
</h2>

<div class="container text-center">
  <div class="row">
    <div class="col"> 

      <div class="card" style="width: 15rem;">
        <img src="public/img/esatu.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
         CBU MT-07 & MT-09 2020 Resmi meluncur, Yamaha Lengkapi MT Series
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/edua.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
         2020 Yamaha MT-25 Launched in Malaysia, Yamaha MT-15 Previewed!
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/etiga.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
          Yamaha MT09 Tracer Sporty Multi Use Bike Resmi Hadir di Indonesia International Motor Show IIMS 2016 Harga Rp.325 
        </p>
      </div>
     </div>

    </div>
  </div>

  <br>

  <div class="row">
    <div class="col"> 

      <div class="card" style="width: 15rem;">
        <img src="public/img/eempat.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
         CBU MT-07 & MT-09 2020 Resmi meluncur, Yamaha Lengkapi MT Series
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/elima.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
          Yamaha Luncurkan MT-15 Bertepatan Dengan Dua Dekade Perjalanan Yamaha MT Series | Berita Seputar Motor | Webike
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/eenam.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
          Yamaha debuts MT-15 limited edition at the 2020 Bangkok Motor Show - AutoTalkBlog
        </p>
      </div>
     </div>

    </div>
  </div>

  <br>

  <div class="row">
    <div class="col"> 

      <div class="card" style="width: 15rem;">
        <img src="public/img/etujuh.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
         CBU MT-07 & MT-09 2020 Resmi meluncur, Yamaha Lengkapi MT Series
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/eventmt.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
          Yamaha Luncurkan MT-15 Bertepatan Dengan Dua Dekade Perjalanan Yamaha MT Series | Berita Seputar Motor | Webike
        </p>
        </div>
     </div>

    </div>
    <div class="col">

    <div class="card" style="width: 15rem;">
        <img src="public/img/eventmt2.jpg" class="card-img-top" alt="...">
         <div class="card-body">
         <p class="card-text">
          Yamaha debuts MT-15 limited edition at the 2020 Bangkok Motor Show - AutoTalkBlog
        </p>
      </div>
     </div>

    </div>
  </div>

</div>
<br><br>
