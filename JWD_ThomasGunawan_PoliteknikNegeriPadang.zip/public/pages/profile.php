<h2>
    Profil Company
</h2>
<p>
Keluarga MT series telah dimulai sejak tahun 1999 dengan mengenalkan MT-01 Concept Model di Tokyo Motor Show. Jenis motor yang satu ini mengusung konsep Kodo ataupun Soul Beat. Selanjutnya, dibutuhkan waktu berkisar 5 tahun untuk melakukan produksi MT-01 secara massal. Hingga pada akhirnya, jenis MT yang lain mulai dihadirkan untuk memenuhi kebutuhan dari pecinta produk Yamaha.
</p>