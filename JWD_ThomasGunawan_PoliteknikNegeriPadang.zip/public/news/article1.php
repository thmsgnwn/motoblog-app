<article id="pro" class="pro">
  <h2>Sejarah MT Yamaha</h2>
  <p>
    Motor berjenis sport naked Yamaha MT-07 dan MT-09 versi 2020 resmi masuk dan
    dijual di Indonesia, ini sejarah singkat dibalik nama MT series. Buat yang
    belum tahu, nama MT sendiri punya arti Master of Torque yang berarti motor
    menawarkan torsi besar saat dikendarai. Penamaan MT series sendiri digunakan
    Yamaha secara global untuk produk motor sport naked yang juga dijadikan
    basis motor R series dikelasnya. “Motor MT series pertama kali muncul lewat
    motor konsep MT-01 yang muncul di pameran Tokyo Motor Show tahun 1999,” buka
    Michael Sudrajat, CBU Sales Manager PT. YIMM. Jika anda ingin hidup 114
    tahun, gunakan trik ini Recommended by Baca Juga: Lebih Segar, Stoplamp LED
    Model Baru dari JPA untuk Yamaha XMAX MT-01 menggunakan mesin besar bertipe
    V-Twin berkapasitas 1.670 cc dengan tenaga 88,9 dk / 4.750 rpm dan torsi
    150,3 Nm / 3.750 rpm.
  </p>
  <p>
    Mulai dari prototipe awal hingga generasi terakhir sekarang, MT series
    menggunakan konsep desain ‘Kodo’ yang merupakan bahasa Jepang dari detak
    jantung.
  </p>
  <p>
  Yamaha MT-01 Concept Model (1999)

Pertama kali Yamaha MT Series muncul, diawali dengan motor konsep MT-01 di Tokyo Motor Show 1999.

Konsep motor ini diberi nama "Kodo", yang merupakan bahasa Jepang dari detak jantung.

Detak jantung itu kombinasi dari dentuman mesin, dorongan yang tercipta dari torsi, getaran suara yang dari intake mesin dan knalpot, sampai detak jantung sang rider.

Yamaha MT-01 sendiri dapat tanggapan positif dari publik, sehingga Yamaha berencana memproduksi massal motor ini.

Yamaha MT-01 (2005-2012)

Akhirnya 5 tahun setelah konsepnya diperlihatkan, Yamaha MT-01 versi produksi massal diperkenalkan.

Motor ini pertama muncul di INTERMOT Jerman 2004, dan punya desain menarik pada zamannya.

Konsep Yamaha MT-01 adalah muscle cruiser, jadi desain bodinya sangat berotot mulai dari tangki sampai knalpot undertail.

Mesin yang dipakai Yamaha MT-01 sendiri, berasal dari cruiser Yamaha Warrior XV1700.

Baca Juga: Sama-sama Pakai Garpu Tala, Ini Tiga Perbedaan Pada Logo Yamaha Motor dengan Yamaha Music

Yamaha
Yamaha MT-01 merupakan motor MT Series pertama yang dijual

Spesifikasinya V-Twin OHV dengan kapasitas 1.670 cc, setara mobil tuh!

Tenaganya 88,9 dk / 4.750 rpm, tidak begitu besar memang, karena mesin ini berasal dari motor cruiser.

Namun torsinya mencapai 150,3 Nm / 3.750 rpm, dan jadi daya tarik buat penyuka motor dengan torsi instan.

Biar tidak begitu laku, MT-01 menjadi langkah awal Yamaha untuk melahirkan MT-series lainnya.
  </p>
</article>




