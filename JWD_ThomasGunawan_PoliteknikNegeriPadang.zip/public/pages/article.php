<h2>Artikel Yamaha MT </h2>
 <!-- Pro -->
 <div class="row articles p-3 m-auto m-auto">
          <article id="pro" class="pro">
              <p>
                <b> Sejarah </b> <a style="text-decoration:none" href="index.php?page=news1">
                <br>Ini Sejarah Yamaha MT Series yang Jarang Orang Tahu, Konsepnya Detak Jantung! </a>
                <br> Motor berjenis sport naked Yamaha MT-07 dan MT-09 versi 2020 resmi masuk dan dijual di Indonesia, ini sejarah singkat dibalik nama MT series. Buat yang belum tahu, nama MT sendiri punya arti Master of Torque...
              </p>
          </article>

          <article id="pro" class="pro">
              <p>
                <b> Yamaha Indonesia Rilis Dua Warna Baru MT-15, Harga Jadi Rp37 jutaan                   
                </b> <a style="text-decoration:none" href="index.php?page=news2">
                <br>
                Yamaha Indonesia rilis dua warna baru buat MT-15.</a> Berkat sentuhan anyar, naked bike 150 cc ini tampil lebih modern. Grafis yang menempel di bodi...
              </p>
          </article>

          <article id="pro" class="pro">
              <p>
                <b> 
                Yamaha MT-15 Punya Dua Warna Baru, Skemanya Mirip MT-25
                </b> 
                
                <br>
                Yamaha Indonesia rilis dua warna anyar buat MT-15. <a style="text-decoration:none" href="index.php?page=news3">
                Sentuhan baru di segmen naked sport</a> 
                ini merupakan jawaban dari permintaan konsumen. Tampil lebih fresh dengan kelir Metallic Dark Grey dan Metallic Blue...
              </p>
          </article>

          <article id="pro" class="pro">
              <p>
                <b> Yamaha Indonesia Rilis Dua Warna Baru MT-15, Harga Jadi Rp37 jutaan                   
                </b> <a style="text-decoration:none" href="index.php?page=news2">
                <br>
                Yamaha Indonesia rilis dua warna baru buat MT-15.</a> Berkat sentuhan anyar, naked bike 150 cc ini tampil lebih modern. Grafis yang menempel di bodi...
              </p>
          </article>

          <article id="pro" class="pro">
              <p>
                <b> 
                Yamaha MT-15 Punya Dua Warna Baru, Skemanya Mirip MT-25
                </b> 
                
                <br>
                Yamaha Indonesia rilis dua warna anyar buat MT-15. <a style="text-decoration:none" href="index.php?page=news3">
                Sentuhan baru di segmen naked sport</a> 
                ini merupakan jawaban dari permintaan konsumen. Tampil lebih fresh dengan kelir Metallic Dark Grey dan Metallic Blue...
              </p>
          </article>


          
         
</div>


        